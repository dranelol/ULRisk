﻿using UnityEngine;
using System.Collections;
using Bolt;

public class clickToMoveController : Bolt.EntityEventListener<ITPCstate>
{
    public LayerMask validLayers = new LayerMask();
    public Vector3 _destinationPosition = Vector3.zero;
    public CharacterController _cc;

    public override void Attached()
    {
        _cc = GetComponent<CharacterController>();
        state.SetTransforms(state.transform, transform);
    }

    public override void SimulateController()
    {
        IclickToMoveCommandInput input = clickToMoveCommand.Create();
        Vector3 position = Input.mousePosition;
        Ray ray = Camera.main.ScreenPointToRay(position);
        RaycastHit[] hits = Physics.RaycastAll(ray, 1000, validLayers);


        if (Input.GetMouseButtonDown(0))
            foreach (RaycastHit hit in hits)
            {
                Debug.Log(hit);
                if (!hit.collider.isTrigger)
                {
                    _destinationPosition = hit.point;
                    break;
                }
            }


        if (_destinationPosition != null)
            input.click = _destinationPosition;
        entity.QueueInput(input);
    }

    public override void ExecuteCommand(Command command, bool resetState)
    {
        clickToMoveCommand cmd = (clickToMoveCommand)command;

        if (resetState)
        {
            //owner has sent a correction to the controller
            transform.position = cmd.Result.position;
            //_cc.Move(cmd.Result.velocity);
        }
        else
        {

            if (cmd.Input.click != null && cmd.Input.click != new Vector3(0, 0, 0))
            {
                if (Vector3.Distance(transform.position, cmd.Input.click) > 0.1f)
                {
                    transform.LookAt(new Vector3(cmd.Input.click.x, transform.position.y, cmd.Input.click.z));
                    _cc.Move(transform.TransformDirection(new Vector3(0, 0, 1) * 0.01f));
                }
            }

            cmd.Result.position = transform.position;
            cmd.Result.velocity = GetComponent<CharacterController>().velocity;
        }
    }

}

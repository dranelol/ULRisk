Thanks for downloading Typogenic, I hope it'll fit your needs ! Full documentation is available in the /Typogenic/Documentation/ folder. Open 'index.html' with your favorite web browser.

If you have any questions or feedback, you can contact me at :

	* Twitter: @Chman
	* Unity Community: http://forum.unity3d.com/members/15388-Chman

Quick links :

	* Asset Store : https://www.assetstore.unity3d.com/en/#!/content/19182
	* Github : https://github.com/Chman/Typogenic
	* Online Documentation : http://thomashourdel.com/typogenic/doc/
	* Forum : http://forum.unity3d.com/threads/typogenic-advanced-text-rendering-free.254978/